import React, {Component}from 'react';
import 'antd/dist/antd.css';
import './index.css';
// import { Layout, Menu, Breadcrumb } from 'antd';
import {
  DesktopOutlined,
  PieChartOutlined,
  FileOutlined,
  TeamOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Row, Col } from 'antd';
import './App.css';
import { Card } from 'antd';

//_______________________NEW LAYOUT__________________________

import 'antd/dist/antd.css';
import './index.css';
import { Layout, Menu, Breadcrumb } from 'antd';

const { Header, Content, Footer } = Layout;

//______________________________________________________________

const { Meta } = Card;

// const { Header, Content, Footer, Sider } = Layout;
const { SubMenu } = Menu;
const style = {"text-align" : "center"};

class App extends Component {
  constructor(){
    super()
    this.state = {
      rgb_pic : '',
      depth_pic : '',
      reconstructed_pic : ''
    }
  }

  componentDidMount(){
    // this.handle()
    // 有返回值的才加（）
    // 有setState的话，需要加.bind(this)
    setInterval(this.handle.bind(this), 300);
    // setInterval(this.test, 1000);
  }

  handle(){
    // var url='/check'
    var url1="http://10.29.51.108:7007/get_color_base64"
    var url2 = "http://10.29.51.108:7007/get_depth_base64"
    var url3 = "http://10.29.51.108:7007/get_reconstructed_base64"
    fetch(url1, {method : "POST"})
    .then(
      res => res.json()
    )
    .then(data1 =>{
      console.log("depth------new")
        this.setState({
          rgb_pic : data1.value
        })
    })
    .catch(e => console.log('error', e))
    

    fetch(url2, {method : "POST"})
    .then(
      res => res.json()
    )
    .then(data2 =>{
      console.log("depth------new")
        this.setState({
          depth_pic : data2.value
        })
    })
    .catch(e => console.log('error', e))


    fetch(url3, {method : "POST"})
    .then(
      res => res.json()
    )
    .then(data3 =>{
      console.log("recon------new")
        this.setState({
          reconstructed_pic : data3.value
        })
    })
    .catch(e => console.log('error', e))
  }

  state = {
    collapsed: false,
  };

  onCollapse = collapsed => {
    console.log(collapsed);
    this.setState({ collapsed });
  };

  render() {
    const { collapsed } = this.state;
    return (
      /*
      <Layout style={{ minHeight: '100vh' }} className="site-layout">
        <Sider collapsible collapsed={collapsed} onCollapse={this.onCollapse}>
          <div className="logo" />
          <Menu theme="dark" defaultSelectedKeys={['1']} mode="inline">
            <Menu.Item key="1" icon={<PieChartOutlined />}>
              Option 1
            </Menu.Item>
            <Menu.Item key="2" icon={<DesktopOutlined />}>
              Option 2
            </Menu.Item>
            <SubMenu key="sub1" icon={<UserOutlined />} title="User">
              <Menu.Item key="3">Tom</Menu.Item>
              <Menu.Item key="4">Bill</Menu.Item>
              <Menu.Item key="5">Alex</Menu.Item>
            </SubMenu>
            <SubMenu key="sub2" icon={<TeamOutlined />} title="Team">
              <Menu.Item key="6">Team 1</Menu.Item>
              <Menu.Item key="8">Team 2</Menu.Item>
            </SubMenu>
            <Menu.Item key="9" icon={<FileOutlined />}>
              Files
            </Menu.Item>
          </Menu>
        </Sider>
        <Layout  className="site-card-border-less-wrapper">
          <Header className="site-layout-background" style={{ padding: 0 }} />

          <Content style={{ margin: '0 16px'}}>
            <Breadcrumb style={{ margin: '16px 0' }}>
              <Breadcrumb.Item>User</Breadcrumb.Item>
              <Breadcrumb.Item>Bill</Breadcrumb.Item>
            </Breadcrumb>
            <div className="site-card-border-less-wrapper">
            <Row gutter={16} justify='space-around'>
              <Col span={6}>
              <Card
                hoverable
                bordered = {true}
                style={{ width: 400 }}
                //cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                cover={<img src = {"data:image/PNG;base64," + (this.state.rgb_pic)} alt = "piccc"></img>}
              >
                <Meta title="实时RGB图像" style={style}/>
              </Card>
              </Col>

              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                // cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                // cover={<img src = {"http://10.29.51.108:7007/get_depth" + "?" + (this.state.img_path)}></img>}
                cover={<img src = {"data:image/PNG;base64," + (this.state.depth_pic)} alt = "piccc"></img>}
              >
                <Meta title="Depth图像" style={style}/>
              </Card>
              </Col>

              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                // cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                // cover={<img src = {"http://10.29.51.108:7007/get_color" + "?" + (this.state.img_path)} alt = "piccc"></img>}
                cover={<img src = {"data:image/PNG;base64," + (this.state.reconstructed_pic)} alt = "piccc"></img>}
              >
                <Meta title="第一视角重建图像" style={style}/>
              </Card>
              </Col>
            </Row>
            <br /><br /><br />
            <Row gutter={16} justify='space-around'>
              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                //cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
              >
                <Meta title="实时RGB图像" style={style}/>
              </Card>
              </Col>

              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                //cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
              >
                <Meta title="实时RGB图像" style={style}/>
              </Card>
              </Col>

              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                //cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
              >
                <Meta title="实时RGB图像" style={style}/>
              </Card>
              </Col>
            </Row>
            </div>
          </Content>
          <Footer style={{ textAlign: 'center' }}>Ant Design ©2018 Created by Ant UED</Footer>
        </Layout>
      </Layout>
      */
      
     
      
      <Layout style={{ minHeight: '100vh' }} className="layout">
      <Header>
        <div className="logo" />
        <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']}>
          <Menu.Item key="1">Virtual Environment</Menu.Item>
          <Menu.Item key="2">Physical Environment</Menu.Item>
        </Menu>
      </Header>
      <Content style={{ padding: '0 50px' }}>
        <div className="site-card-border-less-wrapper">
            <Row gutter={16} justify='space-around'>
              <Col span={6}>
              <Card
                hoverable
                bordered = {true}
                style={{ width: 400 }}
                //cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                cover={<img src = {"data:image/PNG;base64," + (this.state.rgb_pic)} alt = "piccc"></img>}
              >
                <Meta title="实时RGB图像" style={style}/>
              </Card>
              </Col>

              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                // cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                // cover={<img src = {"http://10.29.51.108:7007/get_depth" + "?" + (this.state.img_path)}></img>}
                cover={<img src = {"data:image/PNG;base64," + (this.state.depth_pic)} alt = "piccc"></img>}
              >
                <Meta title="Depth图像" style={style}/>
              </Card>
              </Col>

              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                // cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                // cover={<img src = {"http://10.29.51.108:7007/get_color" + "?" + (this.state.img_path)} alt = "piccc"></img>}
                cover={<img src = {"data:image/PNG;base64," + (this.state.reconstructed_pic)} alt = "piccc"></img>}
              >
                <Meta title="第一视角重建图像" style={style}/>
              </Card>
              </Col>

              <Col span={6}>
              <Card
                hoverable
                style={{ width: 400 }}
                // cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                // cover={<img src = {"http://10.29.51.108:7007/get_color" + "?" + (this.state.img_path)} alt = "piccc"></img>}
                cover={<img src = {"data:image/PNG;base64," + (this.state.reconstructed_pic)} alt = "piccc"></img>}
                // cover={<img src = "scene.jpg" alt = "scene graph"></img>}
              >
                <Meta title="Scene Graph" style={style}/>
              </Card>
              </Col>
            </Row>
            <br />
            <Row gutter={16} justify='start'>
              <Col span={6}>
              <Card title="操作说明" bordered={false} style={{ width: 400 }} hoverable>
                <div>
                  <img src="wasd2.png" alt="wasd" width="120"></img>
                </div>
                <p>使用键盘控制Loomo机器人移动</p>
              </Card>
              </Col>
            
              <Col span={14} offset={3}>
              <Card
                hoverable
                style={{ width: 800 }}
                // cover={<img src = {"/pic" + "?" + (this.state.img_path)} alt = "pic"></img>}
                // cover={<img src = {"http://10.29.51.108:7007/get_depth" + "?" + (this.state.img_path)}></img>}
                cover={<img src = "./recon.png" alt = "piccc"></img>}
              >
                <Meta title="3D 场景重建图" style={style}/>
              </Card>
              </Col>
            </Row>
            
        </div>
      </Content>
      <Footer style={{ textAlign: 'center' }}>Visual Information Processing and Learning ©2020 Created by Ant UED</Footer>
    </Layout>
    
    );
  }
}

export default App